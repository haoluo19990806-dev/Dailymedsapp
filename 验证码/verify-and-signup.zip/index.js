/**
 * MemFire Cloud 云函数 - 验证验证码并注册用户
 * 按照官方格式编写：handler(req, resp, context)
 */

const { createClient } = require('@supabase/supabase-js');

// 全局变量，在 initializer 中初始化
let supabase;

/**
 * 初始化函数 - 云函数启动时执行一次
 */
exports.initializer = (context, callback) => {
    try {
        // 初始化 Supabase 客户端
        supabase = createClient(
            process.env.SUPABASE_URL,
            process.env.SUPABASE_SERVICE_ROLE_KEY
        );

        console.log('[初始化] 成功');
        callback(null, 'successful');
    } catch (e) {
        console.error('[初始化] 失败:', e);
        callback(e);
    }
};

/**
 * 云函数入口 - 按照 MemFire Cloud 官方格式
 * @param {Object} req - 请求对象，包含 method, queries, headers, body
 * @param {Object} resp - 响应对象，包含 setStatusCode, setHeader, send 方法
 * @param {Object} context - 上下文对象
 */
exports.handler = async (req, resp, context) => {
    // 设置 CORS 响应头
    resp.setHeader('Access-Control-Allow-Origin', '*');
    resp.setHeader('Access-Control-Allow-Methods', '*');
    resp.setHeader('Access-Control-Allow-Headers', '*');
    resp.setHeader('Content-Type', 'application/json');

    // 处理 OPTIONS 预检请求
    if (req.method === 'OPTIONS') {
        resp.setStatusCode(204);
        resp.send('');
        return;
    }

    try {
        // 解析请求体
        let email = null;
        let password = null;
        let code = null;
        
        // body 是 Buffer 类型，需要转换
        if (req.body) {
            try {
                const bodyStr = req.body.toString();
                const bodyObj = JSON.parse(bodyStr);
                email = bodyObj.email;
                password = bodyObj.password;
                code = bodyObj.code;
            } catch (e) {
                console.log('[DEBUG] 解析 body 失败:', e);
            }
        }

        console.log('[DEBUG] 收到注册请求, email:', email, ', code:', code ? '******' : undefined);

        // 参数验证
        if (!email || !password || !code) {
            resp.setStatusCode(400);
            resp.send(JSON.stringify({ success: false, error: '请填写完整信息：邮箱、密码和验证码' }));
            return;
        }

        if (!email.includes('@')) {
            resp.setStatusCode(400);
            resp.send(JSON.stringify({ success: false, error: '请输入有效的邮箱地址' }));
            return;
        }

        if (password.length < 6) {
            resp.setStatusCode(400);
            resp.send(JSON.stringify({ success: false, error: '密码长度至少为6位' }));
            return;
        }

        // 如果 initializer 没有执行，这里重新初始化
        if (!supabase) {
            supabase = createClient(
                process.env.SUPABASE_URL,
                process.env.SUPABASE_SERVICE_ROLE_KEY
            );
        }

        // 查询验证码（必须匹配且未过期）
        const now = new Date().toISOString();
        
        const { data: codeRecord, error: queryError } = await supabase
            .from('verification_codes')
            .select('*')
            .eq('email', email)
            .eq('code', code)
            .gte('expires_at', now)
            .order('created_at', { ascending: false })
            .limit(1)
            .single();

        if (queryError || !codeRecord) {
            console.log('[DEBUG] 验证码查询失败:', queryError);
            resp.setStatusCode(400);
            resp.send(JSON.stringify({ success: false, error: '验证码错误或已过期' }));
            return;
        }

        console.log('[DEBUG] 验证码匹配成功');

        // 删除已使用的验证码
        await supabase
            .from('verification_codes')
            .delete()
            .eq('id', codeRecord.id);

        // 创建用户（使用 Admin API）
        const { data: userData, error: signUpError } = await supabase.auth.admin.createUser({
            email: email,
            password: password,
            email_confirm: true, // 验证码已验证，直接确认邮箱
        });

        if (signUpError) {
            console.error('[ERROR] 注册失败:', signUpError);
            
            // 检查是否是用户已存在
            if (signUpError.message.includes('already') || 
                signUpError.message.includes('exists') || 
                signUpError.message.includes('duplicate')) {
                resp.setStatusCode(400);
                resp.send(JSON.stringify({ success: false, error: '该邮箱已被注册，请直接登录' }));
                return;
            }
            
            resp.setStatusCode(500);
            resp.send(JSON.stringify({ success: false, error: '注册失败: ' + signUpError.message }));
            return;
        }

        console.log('[DEBUG] 用户创建成功:', userData.user?.id);

        // 返回成功
        resp.setStatusCode(200);
        resp.send(JSON.stringify({ 
            success: true, 
            message: '注册成功',
            user: { 
                id: userData.user?.id, 
                email: userData.user?.email 
            }
        }));

    } catch (error) {
        console.error('[ERROR] 全局错误:', error);
        resp.setStatusCode(500);
        resp.send(JSON.stringify({ success: false, error: '服务器错误: ' + error.message }));
    }
};
