/**
 * MemFire Cloud 云函数 - 发送邮箱验证码
 * 按照官方格式编写：handler(req, resp, context)
 */

const nodemailer = require('nodemailer');
const { createClient } = require('@supabase/supabase-js');

// 全局变量，在 initializer 中初始化
let supabase;
let transporter;

/**
 * 初始化函数 - 云函数启动时执行一次
 */
exports.initializer = (context, callback) => {
    try {
        // 初始化 Supabase 客户端
        supabase = createClient(
            process.env.SUPABASE_URL,
            process.env.SUPABASE_SERVICE_ROLE_KEY
        );

        // 初始化邮件发送器（QQ邮箱 SMTP）
        transporter = nodemailer.createTransport({
            host: 'smtp.qq.com',
            port: 465,
            secure: true,
            auth: {
                user: process.env.SMTP_USER,
                pass: process.env.SMTP_PASS,
            },
        });

        console.log('[初始化] 成功');
        callback(null, 'successful');
    } catch (e) {
        console.error('[初始化] 失败:', e);
        callback(e);
    }
};

/**
 * 生成 6 位随机验证码
 */
function generateCode() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

/**
 * 云函数入口 - 按照 MemFire Cloud 官方格式
 * @param {Object} req - 请求对象，包含 method, queries, headers, body
 * @param {Object} resp - 响应对象，包含 setStatusCode, setHeader, send 方法
 * @param {Object} context - 上下文对象
 */
exports.handler = async (req, resp, context) => {
    // 设置 CORS 响应头
    resp.setHeader('Access-Control-Allow-Origin', '*');
    resp.setHeader('Access-Control-Allow-Methods', '*');
    resp.setHeader('Access-Control-Allow-Headers', '*');
    resp.setHeader('Content-Type', 'application/json');

    // 处理 OPTIONS 预检请求
    if (req.method === 'OPTIONS') {
        resp.setStatusCode(204);
        resp.send('');
        return;
    }

    try {
        // 解析请求体
        let email = null;
        
        // body 是 Buffer 类型，需要转换
        if (req.body) {
            try {
                const bodyStr = req.body.toString();
                const bodyObj = JSON.parse(bodyStr);
                email = bodyObj.email;
            } catch (e) {
                console.log('[DEBUG] 解析 body 失败:', e);
            }
        }
        
        // 也尝试从 queries 获取
        if (!email && req.queries && req.queries.email) {
            email = req.queries.email;
        }

        console.log('[DEBUG] 收到请求, email:', email);

        // 验证邮箱格式
        if (!email || !email.includes('@')) {
            resp.setStatusCode(400);
            resp.send(JSON.stringify({ success: false, error: '请输入有效的邮箱地址' }));
            return;
        }

        // 检查环境变量
        if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
            console.error('[ERROR] SMTP 配置缺失');
            resp.setStatusCode(500);
            resp.send(JSON.stringify({ success: false, error: 'SMTP 配置缺失' }));
            return;
        }

        // 如果 initializer 没有执行，这里重新初始化
        if (!supabase) {
            supabase = createClient(
                process.env.SUPABASE_URL,
                process.env.SUPABASE_SERVICE_ROLE_KEY
            );
        }
        
        if (!transporter) {
            transporter = nodemailer.createTransport({
                host: 'smtp.qq.com',
                port: 465,
                secure: true,
                auth: {
                    user: process.env.SMTP_USER,
                    pass: process.env.SMTP_PASS,
                },
            });
        }

        // 检查频次（1分钟内只能发送1次）
        const oneMinuteAgo = new Date(Date.now() - 60 * 1000).toISOString();
        const { data: recentCodes, error: selectError } = await supabase
            .from('verification_codes')
            .select('id')
            .eq('email', email)
            .gte('created_at', oneMinuteAgo)
            .limit(1);

        if (selectError) {
            console.error('[DEBUG] 查询频次失败:', selectError);
        } else if (recentCodes && recentCodes.length > 0) {
            resp.setStatusCode(429);
            resp.send(JSON.stringify({ success: false, error: '发送太频繁，请1分钟后再试' }));
            return;
        }

        // 生成验证码
        const code = generateCode();
        const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();
        
        console.log('[DEBUG] 生成验证码:', code);

        // 存入数据库
        const { error: insertError } = await supabase
            .from('verification_codes')
            .insert({
                email: email,
                code: code,
                expires_at: expiresAt,
            });

        if (insertError) {
            console.error('[ERROR] 数据库插入失败:', insertError);
            resp.setStatusCode(500);
            resp.send(JSON.stringify({ success: false, error: '验证码存储失败: ' + insertError.message }));
            return;
        }

        // 发送邮件
        console.log('[DEBUG] 开始发送邮件...');
        
        const mailOptions = {
            from: `"DailyMeds" <${process.env.SMTP_USER}>`,
            to: email,
            subject: '【DailyMeds】您的注册验证码',
            html: `
                <div style="background:#f9f9f9;padding:20px;border-radius:10px;max-width:400px;margin:0 auto;">
                    <h2 style="color:#333;margin-bottom:20px;">DailyMeds 验证码</h2>
                    <p style="color:#666;">您的验证码是：</p>
                    <div style="background:#ecfdf5;padding:15px;border-radius:8px;text-align:center;margin:20px 0;">
                        <span style="color:#059669;font-size:32px;font-weight:bold;letter-spacing:8px;">${code}</span>
                    </div>
                    <p style="color:#999;font-size:12px;">验证码5分钟内有效，如非本人操作请忽略。</p>
                </div>
            `,
        };

        await transporter.sendMail(mailOptions);
        console.log('[DEBUG] 邮件发送成功');

        // 返回成功
        resp.setStatusCode(200);
        resp.send(JSON.stringify({ success: true, message: '验证码已发送' }));

    } catch (error) {
        console.error('[ERROR] 全局错误:', error);
        resp.setStatusCode(500);
        resp.send(JSON.stringify({ success: false, error: '服务器错误: ' + error.message }));
    }
};
